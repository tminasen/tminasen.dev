__turbopack_load_page_chunks__("/", [
  "static/chunks/31r7ymfd1n5pd.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/26au-m0qngndl.js",
  "static/chunks/turbopack-1bd0lcc-bo4t5.js"
])
