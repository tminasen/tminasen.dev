__turbopack_load_page_chunks__("/", [
  "static/chunks/2f47o_5kgq-bf.js",
  "static/chunks/3w4xg5y0a1zis.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/1wo7iz-jvwlps.js",
  "static/chunks/turbopack-111z-a6vvgx0c.js"
])
