__turbopack_load_page_chunks__("/tags", [
  "static/chunks/1p8y8qkuqlkwp.js",
  "static/chunks/3w4xg5y0a1zis.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/1wo7iz-jvwlps.js",
  "static/chunks/turbopack-1hzcqvww0i5yk.js"
])
