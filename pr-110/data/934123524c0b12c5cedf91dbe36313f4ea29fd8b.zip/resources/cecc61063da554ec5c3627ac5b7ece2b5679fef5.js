__turbopack_load_page_chunks__("/", [
  "static/chunks/31r7ymfd1n5pd.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2m0hy4lu4gdvp.js",
  "static/chunks/turbopack-1fh9hm2mohzwd.js"
])
