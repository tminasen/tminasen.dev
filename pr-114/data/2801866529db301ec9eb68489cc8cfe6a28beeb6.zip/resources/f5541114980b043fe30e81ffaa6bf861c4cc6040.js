__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/18ci26sewdzhp.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2fz_sos3oje4f.js",
  "static/chunks/turbopack-2wd1kuzad38h4.js"
])
