__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/3m__0xlya8sxq.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2fz_sos3oje4f.js",
  "static/chunks/turbopack-2k8d4yw2anjwe.js"
])
