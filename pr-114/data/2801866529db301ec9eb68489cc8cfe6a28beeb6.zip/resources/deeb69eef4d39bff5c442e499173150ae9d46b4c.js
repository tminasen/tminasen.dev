__turbopack_load_page_chunks__("/", [
  "static/chunks/026872awu084y.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/22ceexkaeb-sc.js",
  "static/chunks/turbopack-0ry7m8sf-2gon.js"
])
