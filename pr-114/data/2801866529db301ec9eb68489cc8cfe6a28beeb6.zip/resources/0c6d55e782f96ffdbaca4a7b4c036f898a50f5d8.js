__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/36ppd_p8xltsv.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/22ceexkaeb-sc.js",
  "static/chunks/turbopack-31_49ukhy_a8q.js"
])
