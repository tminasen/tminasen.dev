__turbopack_load_page_chunks__("/", [
  "static/chunks/2a_8bga3uenh4.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2fz_sos3oje4f.js",
  "static/chunks/turbopack-0xeelwnxakq62.js"
])
