__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/3ntxtois0ri9a.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0i0_jbx-8npty.js",
  "static/chunks/turbopack-40iz-32w30jk7.js"
])
