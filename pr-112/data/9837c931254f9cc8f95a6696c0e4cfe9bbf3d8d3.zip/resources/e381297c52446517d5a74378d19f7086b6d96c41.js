__turbopack_load_page_chunks__("/", [
  "static/chunks/3vj57ooksc3mt.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0i0_jbx-8npty.js",
  "static/chunks/turbopack-32hsh33-g8gnt.js"
])
