__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/14bbmf0f-vpca.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2m1eqh9x8yap_.js",
  "static/chunks/turbopack-2lq3l0dgb2pw2.js"
])
