__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/18ci26sewdzhp.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2m1eqh9x8yap_.js",
  "static/chunks/turbopack-25b3dfv6ws0sc.js"
])
