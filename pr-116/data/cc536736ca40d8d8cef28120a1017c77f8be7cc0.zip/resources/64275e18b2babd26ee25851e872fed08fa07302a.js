__turbopack_load_page_chunks__("/", [
  "static/chunks/3fskahva-a7u4.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2m1eqh9x8yap_.js",
  "static/chunks/turbopack-26v3hvkoek9-z.js"
])
