__turbopack_load_page_chunks__("/", [
  "static/chunks/3fskahva-a7u4.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/3jfhsks9hpa0o.js",
  "static/chunks/turbopack-23pbg30xoghsf.js"
])
