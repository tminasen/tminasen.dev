__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/14bbmf0f-vpca.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/3jfhsks9hpa0o.js",
  "static/chunks/turbopack-1ii6bkd3mn4re.js"
])
