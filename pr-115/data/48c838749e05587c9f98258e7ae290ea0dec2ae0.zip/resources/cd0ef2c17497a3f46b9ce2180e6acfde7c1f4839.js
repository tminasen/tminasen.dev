__turbopack_load_page_chunks__("/", [
  "static/chunks/3fskahva-a7u4.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/1lodungcplcb3.js",
  "static/chunks/turbopack-15y-w1xk3o_je.js"
])
