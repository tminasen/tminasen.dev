__turbopack_load_page_chunks__("/", [
  "static/chunks/3fskahva-a7u4.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/32-uv6vt053bx.js",
  "static/chunks/turbopack-43ndcbgby7w3n.js"
])
