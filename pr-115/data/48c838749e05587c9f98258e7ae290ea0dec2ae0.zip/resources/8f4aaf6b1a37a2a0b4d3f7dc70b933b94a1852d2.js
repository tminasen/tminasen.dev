__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/18ci26sewdzhp.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/1lodungcplcb3.js",
  "static/chunks/turbopack-16o-i-j7nqjny.js"
])
