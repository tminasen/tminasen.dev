__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/14bbmf0f-vpca.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/32-uv6vt053bx.js",
  "static/chunks/turbopack-1gl77256z103z.js"
])
