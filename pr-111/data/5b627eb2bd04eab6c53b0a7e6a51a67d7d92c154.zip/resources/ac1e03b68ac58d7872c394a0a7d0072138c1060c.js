__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/0fzvuy2rqcnuj.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0z9mm53k71ib2.js",
  "static/chunks/turbopack-3--9nr0hpc0g9.js"
])
