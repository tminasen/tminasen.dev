__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0z9mm53k71ib2.js",
  "static/chunks/turbopack-0z6-tmn0z-k_2.js"
])
