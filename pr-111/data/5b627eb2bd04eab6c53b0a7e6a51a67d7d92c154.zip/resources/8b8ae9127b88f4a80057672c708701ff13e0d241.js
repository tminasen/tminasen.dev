__turbopack_load_page_chunks__("/", [
  "static/chunks/3t4-v2z23s-a7.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0z9mm53k71ib2.js",
  "static/chunks/turbopack-2tgqbzh7f2qi0.js"
])
