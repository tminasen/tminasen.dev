__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/0ybppshhch6qx.js",
  "static/chunks/3w4xg5y0a1zis.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0p4cx98qv94i5.js",
  "static/chunks/turbopack-32r47nq6qz50d.js"
])
