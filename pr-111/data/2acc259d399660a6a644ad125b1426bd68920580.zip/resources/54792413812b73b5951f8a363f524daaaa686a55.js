__turbopack_load_page_chunks__("/tags", [
  "static/chunks/1p8y8qkuqlkwp.js",
  "static/chunks/3w4xg5y0a1zis.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0p4cx98qv94i5.js",
  "static/chunks/turbopack-06unnvh5_fldo.js"
])
