__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/26vy_c6skrt-k.js",
  "static/chunks/turbopack-1wekpsl_a56y_.js"
])
