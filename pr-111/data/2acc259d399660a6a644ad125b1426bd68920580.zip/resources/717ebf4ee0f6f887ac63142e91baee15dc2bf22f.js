__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/0fzvuy2rqcnuj.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/26vy_c6skrt-k.js",
  "static/chunks/turbopack-40s3qrow5rb56.js"
])
