__turbopack_load_page_chunks__("/", [
  "static/chunks/2f47o_5kgq-bf.js",
  "static/chunks/3w4xg5y0a1zis.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0p4cx98qv94i5.js",
  "static/chunks/turbopack-25c7w8g4cpy3y.js"
])
