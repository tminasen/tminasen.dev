__turbopack_load_page_chunks__("/", [
  "static/chunks/3t4-v2z23s-a7.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/26vy_c6skrt-k.js",
  "static/chunks/turbopack-2fbrjpuqa80kj.js"
])
