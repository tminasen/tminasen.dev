__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/0fzvuy2rqcnuj.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/04_jeh3dqje2l.js",
  "static/chunks/turbopack-2nm6f7ubhj15f.js"
])
