__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/32qh1fgwuqpmt.js",
  "static/chunks/1fz47qwnwgpg5.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2ofn21o0t5cjm.js",
  "static/chunks/turbopack-1y8-uzwe61_m4.js"
])
