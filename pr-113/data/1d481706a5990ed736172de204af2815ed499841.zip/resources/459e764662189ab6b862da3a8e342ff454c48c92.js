__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/18ci26sewdzhp.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0m0o7wwh9augn.js",
  "static/chunks/turbopack-2v4tocs4m9q4k.js"
])
