__turbopack_load_page_chunks__("/", [
  "static/chunks/3vj57ooksc3mt.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/12h1hz50wa_co.js",
  "static/chunks/turbopack-3x7dv00aqjv2_.js"
])
