__turbopack_load_page_chunks__("/", [
  "static/chunks/2a_8bga3uenh4.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0m0o7wwh9augn.js",
  "static/chunks/turbopack-1l71n634j4d-4.js"
])
