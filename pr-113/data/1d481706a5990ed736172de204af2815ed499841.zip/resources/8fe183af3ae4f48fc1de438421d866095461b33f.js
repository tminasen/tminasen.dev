__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/12h1hz50wa_co.js",
  "static/chunks/turbopack-2ezn1_8t48i2g.js"
])
