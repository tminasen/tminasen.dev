__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/3ntxtois0ri9a.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/12h1hz50wa_co.js",
  "static/chunks/turbopack-3l27tu3q8q30j.js"
])
