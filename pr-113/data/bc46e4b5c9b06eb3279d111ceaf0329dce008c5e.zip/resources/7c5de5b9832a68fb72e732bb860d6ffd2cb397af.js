__turbopack_load_page_chunks__("/tags/[tag]", [
  "static/chunks/3m__0xlya8sxq.js",
  "static/chunks/0icw1gh31kaak.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/0m0o7wwh9augn.js",
  "static/chunks/turbopack-0pql9gcoqa63s.js"
])
