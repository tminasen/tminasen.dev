__turbopack_load_page_chunks__("/", [
  "static/chunks/398s9d2x7zem9.js",
  "static/chunks/1fz47qwnwgpg5.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2ofn21o0t5cjm.js",
  "static/chunks/turbopack-1xkblwn36g54r.js"
])
