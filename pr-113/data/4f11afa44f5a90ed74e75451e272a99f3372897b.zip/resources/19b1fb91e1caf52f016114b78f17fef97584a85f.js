__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/18ci26sewdzhp.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/2ofn21o0t5cjm.js",
  "static/chunks/turbopack-39o_2mtpmmkbt.js"
])
