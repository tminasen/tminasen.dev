__turbopack_load_page_chunks__("/tags", [
  "static/chunks/25zr-2kvrqylt.js",
  "static/chunks/1dylbc8kw_k4h.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/04_jeh3dqje2l.js",
  "static/chunks/turbopack-2vzssyd57rld5.js"
])
