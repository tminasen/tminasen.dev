__turbopack_load_page_chunks__("/", [
  "static/chunks/31r7ymfd1n5pd.js",
  "static/chunks/3m2pfqp1esdr0.js",
  "static/chunks/22x4yfev5xwea.js",
  "static/chunks/41f7jp7z21-na.js",
  "static/chunks/turbopack-1wnqteip2inz7.js"
])
